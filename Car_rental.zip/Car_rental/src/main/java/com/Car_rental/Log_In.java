package com.Car_rental;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import org.w3c.dom.UserDataHandler;

import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;

import javax.swing.border.EtchedBorder;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.crypto.interfaces.PBEKey;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Log_In {

	static JFrame frame;
	private JTextField userName;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Log_In window = new Log_In();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Log_In() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 542, 398);
		//frame.setBackground(new Color(138, 48, 127));
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		//frame.setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.GREEN);
		panel.setBackground(Color.WHITE);
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(90,60,146), new Color(90,60,146)), "LogIn", TitledBorder.LEADING, TitledBorder.TOP, null,new Color(190, 21, 88)));
		panel.setBounds(46, 95, 424, 234);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("User Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(28, 35, 87, 31);
		panel.add(lblNewLabel_1);
		
		userName = new JTextField();
		userName.setBackground(Color.WHITE);
		userName.setBounds(140, 40, 209, 26);
		panel.add(userName);
		userName.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setBounds(28, 90, 74, 31);
		panel.add(lblNewLabel_1_1);
		
		final JButton logInButton = new JButton("Log In");
		logInButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String userNameString=userName.getText();
				String passwordString=passwordField.getText();
				
				try {
					String dropString="select user_name,password from username where user_name=?";
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
					System.out.println("Connection sucessfull");
					PreparedStatement preparedStatement=connection.prepareStatement(dropString);
					preparedStatement.setString(1, userNameString);
					ResultSet resultSet=preparedStatement.executeQuery();
					
					resultSet.next();
					if (userNameString.equals(resultSet.getString("user_name")) && passwordString.equals(resultSet.getString("password"))) {
						JOptionPane.showMessageDialog(frame, "Log in sucessfull", "Log in",
								JOptionPane.INFORMATION_MESSAGE);
						hide();
						Main_Form main_Form=new Main_Form();
						main_Form.visible();
					}else {
						JOptionPane.showMessageDialog(frame, "User name or Password is not correct", "Account",
								JOptionPane.INFORMATION_MESSAGE);
					}
					preparedStatement.close();
					resultSet.close();
					
					System.out.println("Connection sucessful...");
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		logInButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		logInButton.setForeground(Color.BLACK);
		logInButton.setBackground(Color.WHITE);
		logInButton.setBounds(140, 142, 91, 36);
		panel.add(logInButton);
		
		JButton cancleBtn = new JButton("Cancel");
		cancleBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		cancleBtn.setFont(new Font("Tahoma", Font.BOLD, 13));
		cancleBtn.setForeground(Color.BLACK);
		cancleBtn.setBackground(Color.WHITE);
		cancleBtn.setBounds(256, 142, 91, 36);
		panel.add(cancleBtn);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(Color.WHITE);
		passwordField.setBounds(140, 90, 209, 27);
		panel.add(passwordField);
		
		JButton btnCreateNewAccount = new JButton("Create New Account!!!!");
		btnCreateNewAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				Account account=new Account();
				account.visible();
			}
		});
		btnCreateNewAccount.setForeground(Color.GREEN);
		btnCreateNewAccount.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnCreateNewAccount.setBackground(Color.WHITE);
		btnCreateNewAccount.setBounds(140, 187, 209, 36);
		btnCreateNewAccount.setBorderPainted(false);
		btnCreateNewAccount.setFocusPainted(false) ;
		panel.add(btnCreateNewAccount);
		
		JLabel lblNewLabel = new JLabel("ABC Car Rental LTD...");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 32));
		lblNewLabel.setForeground(new Color(217,19,138));
		lblNewLabel.setBounds(46, 31, 424, 53);
		frame.getContentPane().add(lblNewLabel);
	}

	protected static void hide() {
		frame.hide();
	}
	public  void visible() {
		frame.setVisible(true);
	}
}
