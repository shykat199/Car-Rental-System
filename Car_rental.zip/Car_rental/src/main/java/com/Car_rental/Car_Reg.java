package com.Car_rental;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.mysql.cj.x.protobuf.MysqlxCrud.Update;
import com.mysql.cj.xdevapi.Statement;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Car_Reg {

	private static JFrame frame;
	private JTextField reg_text;
	private JTextField make_text;
	private JTextField model_text;
	private JTable table;
	Connection connection;
	PreparedStatement preparedStatement;
	JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Car_Reg window = new Car_Reg();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public Car_Reg() throws ClassNotFoundException, SQLException {
		initialize();
		autoId() ;
		Refresh();
		//update();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public void autoId() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
		System.out.println("Connection sucessful");
		java.sql.Statement stmtStatement=connection.createStatement();
		ResultSet resultSet=stmtStatement.executeQuery("select Max(Car_reg) from car_reg");
		resultSet.next();
		String regString= resultSet.getString("Max(Car_reg)");
		
		if (regString==null) {
			reg_text.setText("C0001");
		}
		else {
			long id=Long.parseLong(regString.substring(2,regString.length()));
			id++;
			reg_text.setText("C0"+String.format("%03d", id));
			
		}
		
		//String dropString=
		
		
	}
	
	public void update() throws ClassNotFoundException, SQLException {
		
		String dropString="update car_reg set Make=?,Model=?,Available=? where Car_reg=?" ;
		
		DefaultTableModel tableModel= (DefaultTableModel) table.getModel();
		int row=table.getSelectedRow();
		
		String carregistrationString=tableModel.getValueAt(row, 0).toString();
		String makeString=make_text.getText();
		String modelString=model_text.getText();
		String availbleString=comboBox.getSelectedItem().toString();
		
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
		PreparedStatement pst =connection.prepareStatement(dropString);
		
		pst.setString(1, makeString);
		pst.setString(2, modelString);
		pst.setString(3, availbleString);
		pst.setString(4, carregistrationString);
		
		JOptionPane.showMessageDialog(frame, "Sucessfully Edit", "Edit",JOptionPane.INFORMATION_MESSAGE);
		System.out.println("Record Updated");
		
		pst.executeUpdate();
		pst.close();
		
	}
	
	public void Refresh() throws ClassNotFoundException, SQLException {
		
		String dropString="select * from car_reg";
		
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
		PreparedStatement pst=connection.prepareStatement(dropString);
		ResultSet resultSet=pst.executeQuery();
		
		ResultSetMetaData mataData=(ResultSetMetaData) resultSet.getMetaData();
		
		int c=mataData.getColumnCount();
		DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
		tableModel.setRowCount(0);
		
		
		while (resultSet.next()) {
			Vector v2=new Vector();
			
			for (int i = 0; i <=c; i++) {
				v2.add(resultSet.getString("Car_reg"));  //column name
				v2.add(resultSet.getString("Make"));
				v2.add(resultSet.getString("Model"));
				v2.add(resultSet.getString("Available"));
			}
			
			tableModel.addRow(v2);
		}
		
	}
	
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(90,60,146), new Color(90,60,146)), "Car Registration", TitledBorder.LEADING, TitledBorder.TOP, null,new Color(190, 21, 88)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(25, 11, 289, 386);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Car Reg No");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(10, 40, 98, 27);
		panel.add(lblNewLabel);
		
		reg_text = new JTextField();
		reg_text.setBackground(Color.WHITE);
		reg_text.setBounds(131, 40, 148, 27);
		panel.add(reg_text);
		reg_text.setColumns(10);
		
		JLabel lblMake = new JLabel("Make");
		lblMake.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMake.setForeground(Color.BLACK);
		lblMake.setBounds(10, 92, 98, 27);
		panel.add(lblMake);
		
		make_text = new JTextField();
		make_text.setColumns(10);
		make_text.setBackground(Color.WHITE);
		make_text.setBounds(131, 92, 148, 27);
		panel.add(make_text);
		
		JLabel lblModel = new JLabel("Model");
		lblModel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblModel.setForeground(Color.BLACK);
		lblModel.setBounds(10, 145, 98, 27);
		panel.add(lblModel);
		
		model_text = new JTextField();
		model_text.setColumns(10);
		model_text.setBackground(Color.WHITE);
		model_text.setBounds(131, 145, 148, 27);
		panel.add(model_text);
		
		JLabel lblNewLabel_2_1 = new JLabel("Available");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2_1.setForeground(Color.BLACK);
		lblNewLabel_2_1.setBounds(10, 199, 98, 27);
		panel.add(lblNewLabel_2_1);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String  car_regString=reg_text.getText();
				String makeString=make_text.getText();
				String modelString=model_text.getText();
				String availableString=comboBox.getSelectedItem().toString();
				
				String dropString="insert into car_reg values(?,?,?,?)";
				
					try {
						Class.forName("com.mysql.jdbc.Driver");
						connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
						PreparedStatement pst=connection.prepareStatement(dropString);
	                     
	                     pst.setString(1,car_regString);
	 					pst.setString(2,makeString);
	 					pst.setString(3,modelString);
	 					pst.setString(4,availableString);
	 					
	 					pst.executeUpdate();
	 					pst.close();
	 					
					JOptionPane.showMessageDialog(frame, "Sucessfully Updated", "Car Addedd....",
							JOptionPane.INFORMATION_MESSAGE);
					
					System.out.println("Reg:" + reg_text.getText());
					System.out.println("Make:" + make_text.getText());
					System.out.println("Model:" + model_text.getText());
					System.out.println("Availavle:" + comboBox.getSelectedItem().toString());

					reg_text.setText("");
					make_text.setText("");
					model_text.setText("");
					comboBox.setSelectedIndex(0);
					reg_text.requestFocus();

					autoId();
					Refresh();
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
						
				}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBorder(new LineBorder(new Color(217,19,138)));
		btnNewButton.setBounds(10, 258, 111, 33);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Edit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				try {
					update();
					Refresh();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBorder(new LineBorder(new Color(217,19,138)));
		btnNewButton_1.setBounds(168, 258, 111, 33);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Cancle");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				Main_Form main_frame=new Main_Form();
				main_frame.visible();
			}
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1_1.setForeground(Color.BLACK);
		btnNewButton_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1.setBorder(new LineBorder(new Color(217,19,138)));

		btnNewButton_1_1.setBounds(168, 320, 111, 33);
		panel.add(btnNewButton_1_1);
		
		JButton btnNewButton_2 = new JButton("Delete");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
					
					DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
					String dropString="delete from car_reg where  Car_reg=?";
					int row=table.getSelectedRow();
					String nameString=(String) tableModel.getValueAt(row, 0).toString();
					PreparedStatement pStatement=connection.prepareStatement(dropString);
					pStatement.setString(1, nameString);
					JOptionPane.showMessageDialog(frame, "Sucessfully Deleted", "Car Deleat....",JOptionPane.INFORMATION_MESSAGE);
					pStatement.executeUpdate();
					System.out.println("Deleat sucessfull...");
					pStatement.close();
					
					 Refresh();
					
					
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(10, 320, 111, 33);
		btnNewButton_2.setBorder(new LineBorder(new Color(217,19,138)));
		panel.add(btnNewButton_2);
		
		comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 12));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select Availability", "Yes", "No"}));
		comboBox.setForeground(Color.BLACK);
		comboBox.setBackground(Color.WHITE);
		comboBox.setBounds(131, 193, 148, 33);
		panel.add(comboBox);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(335, 11, 428, 386);
		frame.getContentPane().add(scrollPane);
		scrollPane.setBackground(Color.white);
		scrollPane.setForeground(Color.black);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
				int index=table.getSelectedRow();
				
				String carregistrationString=tableModel.getValueAt(index, 0).toString();
				String makeString=tableModel.getValueAt(index, 1).toString();
				String modelString=tableModel.getValueAt(index, 2).toString();
				String availbleString=tableModel.getValueAt(index, 3).toString();
				
				reg_text.setText(carregistrationString);
				make_text.setText(makeString);
				model_text.setText(modelString);
				comboBox.setSelectedItem(availbleString);
			}
		});
		scrollPane.setViewportView(table);
		table.setFont(new Font("Tahoma", Font.BOLD, 11));
		table.setBackground(Color.WHITE);
		table.setForeground(Color.BLACK);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Car_reg", "Make", "Model", "Available"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, true, true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(3).setResizable(false);
		frame.setBounds(100, 100, 789, 460);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	protected static void hide() {
		frame.hide();
	}
	public void visible() {
		frame.setVisible(true);
	}
}
