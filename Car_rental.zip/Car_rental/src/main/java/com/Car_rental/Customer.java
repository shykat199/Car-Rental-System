package com.Car_rental;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.mysql.cj.x.protobuf.MysqlxCrud.Update;
import com.mysql.cj.xdevapi.Statement;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextArea;

public class Customer {

	private static JFrame frame;
	private JTextField customer_Id;
	private JTextField customer_Name;
	private JTable table;
	Connection connection;
	PreparedStatement preparedStatement;
	private JTextField customer_Mobile;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Customer window = new Customer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public Customer() throws ClassNotFoundException, SQLException {
		initialize();
		autoId() ;
		Refresh();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public void autoId() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
		
		System.out.println("Connection sucessful");
		java.sql.Statement stmtStatement=connection.createStatement();
		ResultSet resultSet=stmtStatement.executeQuery("select Max(customer_id) from customer	");
		resultSet.next();
		String regString= resultSet.getString("Max(customer_id)");
		
		if (regString==null) {
			customer_Id.setText("A0001");
		}
		else {
			long id=Long.parseLong(regString.substring(2,regString.length()));
			id++;
			customer_Id.setText("A0"+String.format("%03d", id));
			
		}
		
		//String dropString=
		
		
	}
	
	public void Refresh() throws ClassNotFoundException, SQLException {
		
		String dropString="select * from customer";
		
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
		PreparedStatement pst=connection.prepareStatement(dropString);
		ResultSet resultSet=pst.executeQuery();
		
		ResultSetMetaData mataData=(ResultSetMetaData) resultSet.getMetaData();
		
		int c=mataData.getColumnCount();
		DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
		tableModel.setRowCount(0);
		
		
		while (resultSet.next()) {
			Vector v2=new Vector();
			
			for (int i = 0; i <=c; i++) {
				v2.add(resultSet.getString("customer_id"));  //column name
				v2.add(resultSet.getString("customer_name"));
				v2.add(resultSet.getString("adress"));
				v2.add(resultSet.getString("mobile"));
			}
			
			tableModel.addRow(v2);
		}
		
	}
	
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(90,60,146), new Color(90,60,146)), "Customer Registration", TitledBorder.LEADING, TitledBorder.TOP, null,new Color(190, 21, 88)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(25, 11, 289, 386);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer Id");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(10, 40, 98, 27);
		panel.add(lblNewLabel);
		
		customer_Id = new JTextField();
		customer_Id.setBackground(Color.WHITE);
		customer_Id.setBounds(131, 40, 148, 27);
		panel.add(customer_Id);
		customer_Id.setColumns(10);
		
		JLabel lblMake = new JLabel("Customer Name");
		lblMake.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMake.setForeground(Color.BLACK);
		lblMake.setBounds(10, 92, 111, 27);
		panel.add(lblMake);
		
		customer_Name = new JTextField();
		customer_Name.setColumns(10);
		customer_Name.setBackground(Color.WHITE);
		customer_Name.setBounds(131, 92, 148, 27);
		panel.add(customer_Name);
		
		JLabel lblModel = new JLabel("Address");
		lblModel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblModel.setForeground(Color.BLACK);
		lblModel.setBounds(10, 205, 98, 27);
		panel.add(lblModel);
		
		JLabel lblNewLabel_2_1 = new JLabel("Mobile");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2_1.setForeground(Color.BLACK);
		lblNewLabel_2_1.setBounds(10, 147, 98, 27);
		panel.add(lblNewLabel_2_1);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String  customer_IdString=customer_Id.getText();
				String customer_NameString=customer_Name.getText();
				String customer_AddressString=textArea.getText();
				String customer_MobileString=customer_Mobile.getText();
				
				String dropString="insert into customer(customer_id,customer_name,adress,mobile) values(?,?,?,?)";
				
					try {
						Class.forName("com.mysql.jdbc.Driver");
						connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
						PreparedStatement pst=connection.prepareStatement(dropString);
	                     
	                     pst.setString(1,customer_IdString);
	 					pst.setString(2,customer_NameString);
	 					pst.setString(3,customer_AddressString);
	 					pst.setString(4,customer_MobileString);
	 					
	 					pst.executeUpdate();
	 					//pst.close();
	 					
					JOptionPane.showMessageDialog(frame, "Sucessfully Updated", "Customer Addedd....",
							JOptionPane.INFORMATION_MESSAGE);
					
					
					customer_Name.setText("");
					customer_Mobile.setText("");
					textArea.setText("");
					customer_Name.requestFocus();
					
					System.out.println("Id:" +"\t"+ customer_Id.getText());
					System.out.println("Namae:"+"\t" + customer_Name.getText());
					System.out.println("Mobile:" +"\t"+ customer_Mobile.getText());
					System.out.println("Address:" +"\t"+ textArea.getText());

					autoId();
					Refresh();
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
						
				}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBorder(new LineBorder(new Color(217,19,138)));
		btnNewButton.setBounds(10, 299, 111, 33);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1_1 = new JButton("Cancle");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				Main_Form main_frame=new Main_Form();
				main_frame.visible();
			}
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1_1.setForeground(Color.BLACK);
		btnNewButton_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1.setBorder(new LineBorder(new Color(217,19,138)));

		btnNewButton_1_1.setBounds(168, 299, 111, 33);
		panel.add(btnNewButton_1_1);
		
		customer_Mobile = new JTextField();
		customer_Mobile.setColumns(10);
		customer_Mobile.setBackground(Color.WHITE);
		customer_Mobile.setBounds(131, 148, 148, 27);
		panel.add(customer_Mobile);
		Border border = BorderFactory.createLineBorder(Color.BLACK);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(131, 194, 148, 65);
		panel.add(scrollPane_1);
		
		textArea = new JTextArea();
		scrollPane_1.setViewportView(textArea);
		textArea.setBackground(Color.WHITE);
		textArea.setBorder(BorderFactory.createCompoundBorder(border,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(335, 11, 428, 386);
		frame.getContentPane().add(scrollPane);
		scrollPane.setBackground(Color.white);
		scrollPane.setForeground(Color.black);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tableModel=(DefaultTableModel) table.getModel();
				int index=table.getSelectedRow();
				
				String customer_IdString=tableModel.getValueAt(index, 0).toString();
				String customer_NameString=tableModel.getValueAt(index, 1).toString();
				String customer_AddressString=tableModel.getValueAt(index, 2).toString();
				String customer_MobileString=tableModel.getValueAt(index, 3).toString();
				
				customer_Id.setText(customer_IdString);
				customer_Name.setText(customer_NameString);
				textArea.setText(customer_AddressString);
				customer_Mobile.setText(customer_MobileString);
			}
		});
		scrollPane.setViewportView(table);
		table.setFont(new Font("Tahoma", Font.BOLD, 11));
		table.setBackground(Color.WHITE);
		table.setForeground(Color.BLACK);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"customer_id", "customer_name", "adress", "mobile"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, true, true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(3).setResizable(false);
		frame.setBounds(100, 100, 789, 460);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	protected static void hide() {
		frame.hide();
	}
	public void visible() {
		frame.setVisible(true);
	}
}
