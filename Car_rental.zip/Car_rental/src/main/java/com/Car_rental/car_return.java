package com.Car_rental;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.mysql.cj.x.protobuf.MysqlxCrud.Update;
import com.mysql.cj.xdevapi.Statement;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class car_return {
//01736559450
	private static JFrame frame;
	private JTextField reg_text;
	private JTextField cust_id;
	private JTextField date;
	private JTable table;
	Connection connection;
	PreparedStatement preparedStatement;
	private JTextField elaps_date;
	private JTextField fine_text;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					car_return window = new car_return();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public car_return() throws ClassNotFoundException, SQLException {
		initialize();
		// autoId() ;
		Refresh();
		// update();
	}

	
	public void Refresh() throws ClassNotFoundException, SQLException {

		String dropString = "select * from return_car order by car_id";

		Class.forName("com.mysql.jdbc.Driver");
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration", "root", "root");
		PreparedStatement pst = connection.prepareStatement(dropString);
		ResultSet resultSet = pst.executeQuery();

		ResultSetMetaData mataData = (ResultSetMetaData) resultSet.getMetaData();

		int c = mataData.getColumnCount();
		DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
		tableModel.setRowCount(0);

		while (resultSet.next()) {
			Vector v2 = new Vector();

			for (int i = 0; i <= c; i++) {
				v2.add(resultSet.getString("car_id")); // column name
				v2.add(resultSet.getString("cust_id"));
				v2.add(resultSet.getString("return_date"));
				v2.add(resultSet.getString("elaps_date"));
				v2.add(resultSet.getString("fine"));

			}

			tableModel.addRow(v2);
		}

	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(
				new EtchedBorder(EtchedBorder.LOWERED, new Color(90, 60, 146), new Color(90, 60, 146)),
				"Car Rental Information", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(190, 21, 88)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(25, 72, 289, 315);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Car Reg No");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(10, 40, 98, 27);
		panel.add(lblNewLabel);

		reg_text = new JTextField();
		reg_text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {

				if (e.getKeyCode() == KeyEvent.VK_ENTER) {

					try {
						String dropString = "select car_id,customar_id,due_date,DATEDIFF(NOW(),due_date) as elaps from rental where car_id=?";

						Class.forName("com.mysql.jdbc.Driver");
						connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration", "root",
								"root");

						String carIdString = reg_text.getText();

						preparedStatement = connection.prepareStatement(dropString);
						preparedStatement.setString(1, carIdString);
						ResultSet resultSet = preparedStatement.executeQuery();
						if (resultSet.next() == false) {

							JOptionPane.showMessageDialog(frame, "Car Id not found.....", "Car Return",
									JOptionPane.INFORMATION_MESSAGE);

						} else {
							String custIdString = resultSet.getString("customar_id");
							cust_id.setText(custIdString.trim());

							String dateString = resultSet.getString("due_date");
							date.setText(dateString.trim());

							String elapString = resultSet.getString("elaps");

							int elaps = Integer.parseInt(elapString);

							if (elaps > 0) {
								elaps_date.setText(elapString);

								int fine = elaps * 100;
								fine_text.setText(String.valueOf(fine));

							} else {
								elaps_date.setText("0");
								fine_text.setText("0");
							}

						}

					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}

			}
		});
		reg_text.setBackground(Color.WHITE);
		reg_text.setBounds(131, 40, 148, 27);
		panel.add(reg_text);
		reg_text.setColumns(10);

		JLabel lblMake = new JLabel("Customer Id");
		lblMake.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMake.setForeground(Color.BLACK);
		lblMake.setBounds(10, 92, 98, 27);
		panel.add(lblMake);

		cust_id = new JTextField();
		cust_id.setColumns(10);
		cust_id.setBackground(Color.WHITE);
		cust_id.setBounds(131, 92, 148, 27);
		panel.add(cust_id);

		JLabel lblModel = new JLabel("Date");
		lblModel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblModel.setForeground(Color.BLACK);
		lblModel.setBounds(10, 145, 98, 27);
		panel.add(lblModel);

		date = new JTextField();
		date.setColumns(10);
		date.setBackground(Color.WHITE);
		date.setBounds(131, 145, 148, 27);
		panel.add(date);

		JLabel lblNewLabel_2_1 = new JLabel("Date Elapsed");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2_1.setForeground(Color.BLACK);
		lblNewLabel_2_1.setBounds(10, 199, 98, 27);
		panel.add(lblNewLabel_2_1);

		elaps_date = new JTextField();
		elaps_date.setColumns(10);
		elaps_date.setBackground(Color.WHITE);
		elaps_date.setBounds(131, 200, 148, 27);
		panel.add(elaps_date);

		fine_text = new JTextField();
		fine_text.setColumns(10);
		fine_text.setBackground(Color.WHITE);
		fine_text.setBounds(131, 256, 148, 27);
		panel.add(fine_text);

		JLabel lblNewLabel_2_1_1 = new JLabel("Fine");
		lblNewLabel_2_1_1.setForeground(Color.BLACK);
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2_1_1.setBounds(10, 255, 98, 27);
		panel.add(lblNewLabel_2_1_1);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(335, 72, 428, 359);
		frame.getContentPane().add(scrollPane);
		scrollPane.setBackground(Color.white);
		scrollPane.setForeground(Color.black);

		table = new JTable();
		/*table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
				int index = table.getSelectedRow();

				String carregistrationString = tableModel.getValueAt(index, 0).toString();
				String makeString = tableModel.getValueAt(index, 1).toString();
				String modelString = tableModel.getValueAt(index, 2).toString();
				String availbleString = tableModel.getValueAt(index, 3).toString();

				reg_text.setText(carregistrationString);
				cust_id.setText(makeString);
				date.setText(modelString);
				// comboBox.setSelectedItem(availbleString);
			}
		});*/
		scrollPane.setViewportView(table);
		table.setFont(new Font("Tahoma", Font.BOLD, 11));
		table.setBackground(Color.WHITE);
		table.setForeground(Color.BLACK);
		table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "car_id", "cust_id", "return_date", "elaps_date", "fine" }) {
			boolean[] columnEditables = new boolean[] { true, true, true, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});

		JLabel lblNewLabel_1 = new JLabel("Return Car");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 32));
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(163, 11, 390, 34);
		frame.getContentPane().add(lblNewLabel_1);

		JButton btnNewButton = new JButton("Ok");
		btnNewButton.setBounds(45, 398, 111, 33);
		frame.getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String car_IdString = reg_text.getText();
				String cust_idString = cust_id.getText();
				String dateString = date.getText();
				String elapString = elaps_date.getText();
				String fineString = fine_text.getText();


				String dropString = "insert into return_car values(?,?,?,?,?) ";

				try {
					Class.forName("com.mysql.jdbc.Driver");
					connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration", "root",
							"root");
					PreparedStatement pst = connection.prepareStatement(dropString);

					pst.setString(1, car_IdString);
					pst.setString(2, cust_idString);
					pst.setString(3, dateString);
					pst.setString(4, elapString);
					pst.setString(5, fineString);

					pst.executeUpdate();
					pst.close();
					
					
					String dropString2="Update car_reg set Available='Yes' where Car_reg=?";
					
					PreparedStatement pst1=connection.prepareStatement(dropString2);
					pst1.setString(1, car_IdString);
					pst1.executeUpdate();
					pst1.close();

					
					String dropString3="Delete from rental where car_id=?";
					PreparedStatement pst2=connection.prepareStatement(dropString3);
					pst2.setString(1, car_IdString);
					pst2.executeUpdate();
					pst2.close();
					

					JOptionPane.showMessageDialog(frame, "Return Sucessfully....", "Car Return",
							JOptionPane.INFORMATION_MESSAGE);

					System.out.println("Car Id:" + "\t" + reg_text.getText());
					System.out.println("Customer Id:" + "\t " + cust_id.getText());
					System.out.println("Date:" + "\t " + date.getText());
					System.out.println("Claps Date:" + "\t " + elaps_date.getText());
					System.out.println("Fine:" + "\t " + fine_text.getText());

					reg_text.setText("");
					cust_id.setText("");
					date.setText("");
					elaps_date.setText("");
					fine_text.setText("");
					reg_text.requestFocus();

					// autoId();
					Refresh();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBorder(new LineBorder(new Color(217, 19, 138)));

		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.setBounds(203, 398, 111, 33);
		frame.getContentPane().add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				Main_Form main_frame=new Main_Form();
				main_frame.visible();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBorder(new LineBorder(new Color(217, 19, 138)));
		table.getColumnModel().getColumn(3).setResizable(false);
		frame.setBounds(100, 100, 789, 481);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	protected static void hide() {
		frame.hide();
	}

	public void visible() {
		frame.setVisible(true);
	}
}
