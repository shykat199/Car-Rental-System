package com.Car_rental;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import org.w3c.dom.UserDataHandler;

import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;

import javax.swing.border.EtchedBorder;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.crypto.interfaces.PBEKey;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Account {

	static JFrame frame;
	private JTextField userName;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Account window = new Account();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Account() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 542, 380);
		//frame.setBackground(new Color(138, 48, 127));
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		//frame.setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.GREEN);
		panel.setBackground(Color.WHITE);
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(90, 60, 146), new Color(90, 60, 146)), "Create Account", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(190, 21, 88)));
		panel.setBounds(46, 95, 424, 219);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("User Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(28, 35, 87, 31);
		panel.add(lblNewLabel_1);
		
		userName = new JTextField();
		userName.setBackground(Color.WHITE);
		userName.setBounds(140, 40, 209, 26);
		panel.add(userName);
		userName.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setBounds(28, 90, 74, 31);
		panel.add(lblNewLabel_1_1);
		
		final JButton logInButton = new JButton("Ok");
		logInButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String userNameString=userName.getText();
				String passwordString=passwordField.getText();
				
				try {
					//System.out.println("cccConnection sucessful...");
					String dropString="insert into username values(?,?)";
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration","root","root");
					System.out.println("Connection sucessful...");
					PreparedStatement preparedStatement=connection.prepareStatement(dropString);
					preparedStatement.setString(1, userNameString);
					preparedStatement.setString(2, passwordString);
					preparedStatement.executeUpdate();
					preparedStatement.close();
					
					JOptionPane.showMessageDialog(frame, "Account Created....", "Account Create",
							JOptionPane.INFORMATION_MESSAGE);
					
					System.out.println("User Name:"+"\t"+userNameString);
					System.out.println("User Name:"+"\t"+passwordString);
					
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		logInButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		logInButton.setForeground(Color.BLACK);
		logInButton.setBackground(Color.WHITE);
		logInButton.setBounds(140, 142, 91, 36);
		panel.add(logInButton);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(Color.WHITE);
		passwordField.setBounds(140, 90, 209, 27);
		panel.add(passwordField);
		
		JButton btnCancle = new JButton("Cancle");
		btnCancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				Log_In log_In=new  Log_In();
				log_In.visible();
				
			}
		});
		btnCancle.setForeground(Color.BLACK);
		btnCancle.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnCancle.setBackground(Color.WHITE);
		btnCancle.setBounds(257, 142, 91, 36);
		panel.add(btnCancle);
		
		JLabel lblNewLabel = new JLabel("Create New Account");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 32));
		lblNewLabel.setForeground(new Color(217,19,138));
		lblNewLabel.setBounds(46, 31, 424, 53);
		frame.getContentPane().add(lblNewLabel);
	}

	protected static void hide() {
		frame.hide();
	}
	public  void visible() {
		frame.setVisible(true);
	}
}
