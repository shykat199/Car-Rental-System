package com.Car_rental;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.jgoodies.forms.factories.DefaultComponentFactory;
import com.jcalendar.model.JCalModel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JMonthChooser;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Rental {

	private static JFrame frame;
	private JTextField customer_id;
	private JTextField customer_name;
	private JTextField rental_fee;
	JComboBox comboBox;
	Connection connection;
	PreparedStatement preparedStatement;
	PreparedStatement	preparedStatement1;
	private JTextField avail_text;
	private JTextField car_text;
	JDateChooser dateChooser;
	JDateChooser dateChooser_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rental window = new Rental();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public Rental() throws ClassNotFoundException, SQLException {
		initialize();
		LoadCarId();
	}

	public void LoadCarId() throws ClassNotFoundException, SQLException {

		String dropString = "select * from car_reg";

		Class.forName("com.mysql.jdbc.Driver");
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration", "root", "root");
		preparedStatement = connection.prepareStatement(dropString);
		ResultSet resultSet = preparedStatement.executeQuery();

		comboBox.removeAllItems();

		while (resultSet.next()) {
			comboBox.addItem(resultSet.getString(1));
		}

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		JPanel panel = new JPanel();
		panel.setBorder(
				new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(243, 205, 5), new Color(243, 205, 5)),
						"Customer Registration", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(190, 21, 88)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(10, 11, 455, 488);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Car Id");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(40, 55, 112, 25);
		panel.add(lblNewLabel);

		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String carIdString = comboBox.getSelectedItem().toString();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration", "root",
							"root");
					preparedStatement = connection.prepareStatement("select * from car_reg Where Car_reg=?");
					preparedStatement.setString(1, carIdString);

					ResultSet resultSet = preparedStatement.executeQuery();

					if (resultSet.next() == false) {
						JOptionPane.showMessageDialog(frame, "Car is not available", null,
								JOptionPane.INFORMATION_MESSAGE);

					} else {

						String availableString = resultSet.getString("Available");
						avail_text.setText(availableString.trim());
						String CarnameString = resultSet.getString("Make");
						car_text.setText(CarnameString.trim());

						if (availableString.equals("Yes")) {

							customer_id.setEnabled(true);
							customer_name.setEnabled(true);
							rental_fee.setEnabled(true);
							dateChooser.setEnabled(true);
							dateChooser_1.setEnabled(true);

						}
						else {
							
							customer_id.setEnabled(false);
							customer_name.setEnabled(false);
							rental_fee.setEnabled(false);
							dateChooser.setEnabled(false);
							dateChooser_1.setEnabled(false);
							
						}

					}

				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		comboBox.setBackground(Color.WHITE);
		comboBox.setBounds(246, 55, 141, 25);
		panel.add(comboBox);

		JLabel lblNewLabel_1 = new JLabel("Customer ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(40, 209, 112, 25);
		panel.add(lblNewLabel_1);

		customer_id = new JTextField();
		customer_id.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					
					String customr_idString=customer_id.getText();
					
					try {
						Class.forName("com.mysql.jdbc.Driver");
						connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration", "root",
								"root");
					preparedStatement1 = connection.prepareStatement("select * from customer Where customer_id=?");
					preparedStatement1.setString(1, customr_idString);
					ResultSet resultSet=preparedStatement1.executeQuery();
					
						if (resultSet.next() == false) {
							JOptionPane.showMessageDialog(frame, "Customer is not Available", null,
									JOptionPane.INFORMATION_MESSAGE);
						}

						else {
							String availableString = resultSet.getString("customer_name");
							customer_name.setText(availableString.trim());
						}
					
					
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					
				}
				
			}
		});
		customer_id.setBackground(Color.WHITE);
		customer_id.setBounds(246, 209, 141, 25);
		panel.add(customer_id);
		customer_id.setColumns(10);
		customer_id.setEnabled(false);

		customer_name = new JTextField();
		customer_name.setColumns(10);
		customer_name.setBackground(Color.WHITE);
		customer_name.setBounds(246, 260, 141, 25);
		panel.add(customer_name);
		customer_name.setEnabled(false);

		JLabel lblNewLabel_1_1 = new JLabel("Customer Name");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setBounds(40, 260, 112, 25);
		panel.add(lblNewLabel_1_1);

		rental_fee = new JTextField();
		rental_fee.setColumns(10);
		rental_fee.setBackground(Color.WHITE);
		rental_fee.setBounds(246, 310, 141, 25);
		panel.add(rental_fee);
		rental_fee.setEnabled(false);

		JLabel lblNewLabel_1_2 = new JLabel("Rental Fee");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_2.setForeground(Color.BLACK);
		lblNewLabel_1_2.setBounds(40, 310, 112, 25);
		panel.add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_3 = new JLabel("Date");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3.setForeground(Color.BLACK);
		lblNewLabel_1_3.setBounds(40, 357, 112, 25);
		panel.add(lblNewLabel_1_3);

		JLabel lblNewLabel_1_4 = new JLabel("Due Date");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_4.setForeground(Color.BLACK);
		lblNewLabel_1_4.setBounds(40, 403, 112, 25);
		panel.add(lblNewLabel_1_4);

		JButton btnNewButton = new JButton("Ok");
		btnNewButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				
				String carIdString=comboBox.getSelectedItem().toString();
				String carNameString=car_text.getText();
				String custIdString=customer_id.getText();
				String customerNameString=customer_name.getText();
				String feeString=rental_fee.getText();
				
				SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
				String dateString=dateFormat.format(dateChooser.getDate());
				
				SimpleDateFormat dateFormat1=new SimpleDateFormat("yyyy-MM-dd");
				String dueString=dateFormat1.format(dateChooser_1.getDate());
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_registration", "root",
							"root");
				preparedStatement1= connection.prepareStatement("insert into rental values(?,?,?,?,?,?,?)");
				preparedStatement1.setString(1, carIdString);
				preparedStatement1.setString(2, carNameString);
				preparedStatement1.setString(3, custIdString);
				preparedStatement1.setString(4, customerNameString);
				preparedStatement1.setString(5, feeString);
				preparedStatement1.setString(6, dateString);
				preparedStatement1.setString(7, dueString);
				preparedStatement1.executeUpdate();

				PreparedStatement preparedStatement2=connection.prepareStatement("update car_reg set Available='No'Where Car_reg=? ");
				preparedStatement2.setString(1, carIdString);
				preparedStatement2.executeUpdate();
				
				JOptionPane.showMessageDialog(frame, "Success ", null,
						JOptionPane.INFORMATION_MESSAGE);
				
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(205, 439, 91, 38);
		panel.add(btnNewButton);

		JButton btnCancle = new JButton("Cancle");
		btnCancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				Main_Form main_frame=new Main_Form();
				main_frame.visible();
			}
		});
		btnCancle.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnCancle.setForeground(Color.BLACK);
		btnCancle.setBackground(Color.WHITE);
		btnCancle.setBounds(343, 439, 91, 38);
		panel.add(btnCancle);

		dateChooser = new JDateChooser();
		dateChooser.setBounds(246, 357, 141, 25);
		dateChooser.setDateFormatString("yyyy-mm-dd");
		panel.add(dateChooser);
		dateChooser.setEnabled(false);

		dateChooser_1 = new JDateChooser();
		dateChooser_1.setBounds(246, 403, 141, 25);
		dateChooser_1.setDateFormatString("yyyy-mm-dd");
		panel.add(dateChooser_1);
		dateChooser_1.setEnabled(false);

		avail_text = new JTextField();
		avail_text.setBackground(Color.WHITE);
		avail_text.setBounds(246, 156, 141, 25);
		panel.add(avail_text);
		avail_text.setColumns(10);

		JLabel lblNewLabel_1_5 = new JLabel("Car Name");
		lblNewLabel_1_5.setForeground(Color.BLACK);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_5.setBounds(40, 103, 112, 25);
		panel.add(lblNewLabel_1_5);

		car_text = new JTextField();
		car_text.setColumns(10);
		car_text.setBackground(Color.WHITE);
		car_text.setBounds(246, 103, 141, 25);
		panel.add(car_text);

		JLabel lblNewLabel_1_6 = new JLabel("Availability");
		lblNewLabel_1_6.setForeground(Color.BLACK);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_6.setBounds(40, 155, 112, 25);
		panel.add(lblNewLabel_1_6);
		frame.setBounds(100, 100, 496, 549);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	protected static void hide() {
		frame.hide();
	}
	void visible() {
		frame.setVisible(true);
	}
}
