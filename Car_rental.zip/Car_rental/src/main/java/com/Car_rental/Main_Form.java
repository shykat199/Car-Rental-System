package com.Car_rental;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Main_Form {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_Form window = new Main_Form();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main_Form() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setLocationRelativeTo(null);
		//Border myRaisedBorder = BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.PINK, Color.RED);
		frame.getContentPane().setLayout(null);
		

		
		JButton btnNewButton = new JButton("Car Registration");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Car_Reg car_Reg=new Car_Reg();
					car_Reg.visible();
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBorder(new LineBorder(new Color(217,19,138)));
		btnNewButton.setBounds(119, 39, 155, 38);
		btnNewButton.setFocusable(false);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Customer");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Customer customer=new Customer();
					customer.visible();
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBorder(new LineBorder(new Color(217,19,138)));
		btnNewButton_1.setBounds(119, 104, 155, 38);
		btnNewButton_1.setFocusable(false);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Rental");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Rental rental=new Rental();
					rental.visible();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				frame.setVisible(false);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBorder(new LineBorder(new Color(217,19,138)));
		btnNewButton_2.setBounds(119, 172, 155, 38);
		btnNewButton_2.setFocusable(false);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Return");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					car_return car_return=new car_return();
					car_return.visible();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				frame.setVisible(false);
			}
				
			
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_3.setForeground(Color.BLACK);
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBorder(new LineBorder(new Color(217,19,138)));
		btnNewButton_3.setBounds(119, 243, 155, 38);
		btnNewButton_3.setFocusable(false);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Logout");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
					Log_In log_In=new Log_In();
					log_In.visible();
			
				
				frame.setVisible(false);
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_4.setForeground(Color.BLACK);
		btnNewButton_4.setBackground(Color.WHITE);
		btnNewButton_4.setBorder(new LineBorder(new Color(217,19,138)));
		btnNewButton_4.setBounds(119, 318, 155, 38);
		frame.getContentPane().add(btnNewButton_4);
		btnNewButton_4.setFocusable(false);
		frame.setBounds(100, 100, 413, 437);
		frame.setLocationRelativeTo(null);
		visible();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	void visible() {
		frame.setVisible(true);
	}

}
